const express=require('express');
const routers=express.Router();


const IGctrl=require('../controllers/IG.controllers');
const IGAccessServices=require('../Middleware/IGAccess.mdw');
const tokenservices=require('../Middleware/token.mdw');


routers.post('/',IGctrl.createIG);
routers.post('/login',IGctrl.login);
routers.get('/getAll',tokenservices.AuthorizationIG,IGAccessServices.getAll);
routers.get('/:id',tokenservices.AuthorizationIG,IGAccessServices.getById);
routers.put('/:id',tokenservices.AuthorizationIG,IGAccessServices.update);



module.exports=routers;