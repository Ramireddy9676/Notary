const express=require('express');
const routers=express.Router();


const DIGctrl=require('../controllers/DIG.controllers');
const DIGAccessServices=require('../Middleware/DIGAccess.mdw');
const tokenservices=require('../Middleware/token.mdw');


routers.post('/',DIGctrl.createDIG);
routers.post('/login',DIGctrl.login);
routers.get('/getAll',tokenservices.AuthorizationDIG,DIGAccessServices.getAll);
routers.get('/:id',tokenservices.AuthorizationDIG,DIGAccessServices.getById);
routers.put('/:id',tokenservices.AuthorizationDIG,DIGAccessServices.update);



module.exports=routers;