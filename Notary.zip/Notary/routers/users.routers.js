const express=require('express');
const routers=express.Router();

const usersControllers=require('../controllers/users.controllers');
const tokenservices = require('../Middleware/token.mdw');


routers.post('/',usersControllers.userRegistration);
routers.post('/validateRegisterOTP',usersControllers.validateRegisterOTP);
routers.post('/login',usersControllers.login);
routers.post('/validateloginOTP',usersControllers.validateloginOTP);

module.exports=routers;