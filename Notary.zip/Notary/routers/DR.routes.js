const express=require('express');
const routers=express.Router();


const DRctrl=require('../controllers/DR.controllers');
const DRAccessServices=require('../Middleware/DRAccess.mdw');
const tokenservices=require('../Middleware/token.mdw');

routers.post('/',DRctrl.createDR);
routers.post('/login',DRctrl.login);
routers.get('/getall',tokenservices.AuthorizationDR,DRAccessServices.getAll);
routers.get('/:id',tokenservices.AuthorizationDR,DRAccessServices.getById);
routers.put('/:id',tokenservices.AuthorizationDR,DRAccessServices.update);

module.exports=routers;