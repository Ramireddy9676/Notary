const express=require('express');
const routers=express.Router();


const renewalsctrl=require('../controllers/renewals.controllers');
const tokenservices = require('../Middleware/token.mdw');

routers.post('/',tokenservices.Authorization,renewalsctrl.createRenewals);
routers.put('/:id',tokenservices.Authorization,renewalsctrl.update);
routers.get('/:id',renewalsctrl.getById)



module.exports=routers;