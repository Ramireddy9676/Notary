const mongoose=require('mongoose');

const renewalsSchema=mongoose.Schema({
    applicationId:{
        type:'String'
    },
    TypeofRenewal:{
        type:'String'

    },
    enrollmentNumber:{
        type:'String'
    },
    PreviousLicenseGONumber:{
        type:'String'
    },
    PreviousLicenseGOSlNo:{
        type:'String'
    },
    certificateIssuedDate:{
        type:'Date'
    },
    certificateEndDate:{
        type:'Date'
    },
    aadhaarNumber:{
        type:'Number'
    },
    name:{
        type:'String'
    },
    relationName:{
        type:'String'
    },
    dateOfBirth:{
        type:'String'
    },
    // gender:{
    //     type:'String'
    // },
    email:{
        type:'String'
    },
    mobile:{
        type:'Number'
    },
    officeAddress:{
        doorNo:{
            type:'String'
        },
        street:{
            type:'String'
        },
        district:{
            type:'String'
        },
        mandal:{
            type:'String'
        },
        village:{
            type:'String'
        },
        pincode:{
            type:'Number'
        }

    },
    homeAddress:{
        doorNo:{
            type:'String'
        },
        street:{
            type:'String'
        },
        district:{
            type:'String'
        },
        mandal:{
            type:'String'
        },
        village:{
            type:'String'
        },
        pincode:{
            type:'Number'
        }

    },
    DRcomments:{
        type:'String'
    },
    DIGcomments:{
        type:'String'
    },
    IGcomments:{
        type:'String'
    },
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'users'
    }

},{
    timestamps:true
})
const renewalsmodels=mongoose.model('renewals',renewalsSchema);
module.exports=renewalsmodels;