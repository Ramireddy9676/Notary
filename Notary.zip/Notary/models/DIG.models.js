const mongoose=require('mongoose');


const DIGSchema=mongoose.Schema({
    Email:{
        type:'String'
    },
    Password:{
        type:'String'
    },
    token:{
        type:'String'
    },
    role: { 
        type: 'String'
    },
   

})
const DIGmodels=mongoose.model('DIG',DIGSchema);
module.exports=DIGmodels;