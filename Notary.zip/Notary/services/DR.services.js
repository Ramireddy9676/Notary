
const DRmodels=require('../models/DR.models');


const DRServices={
    create:(data)=>{
        const createDR=new DRmodels(data);
        return createDR.save();
    },
    getByEmail:(Email)=>{
        return DRmodels.findOne({Email})
    }

}
module.exports=DRServices;