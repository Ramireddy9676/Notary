const renewalsmodels=require('../models/renewals.models');


const renewalsServices={
    create:(data)=>{
        const createrenewwals=new renewalsmodels(data);
        return createrenewwals.save();
    },
    getById:(id)=>{
        return renewalsmodels.findById(id);

    },
    update:(id,data)=>{
        return renewalsmodels.findByIdAndUpdate(id,data,{new:true})
    },
    getAll:()=>{
        return renewalsmodels.find();
    }

}
module.exports=renewalsServices;