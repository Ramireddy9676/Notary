const DIGservices = require('../services/DIG.services');
const bcrypt = require('bcrypt');
const tokenservices = require('../Middleware/token.mdw');



const DIGctrl = {
    createDIG: async (req, res) => {
        try {
            const Passwordhased = await bcrypt.hash(req.body.Password, 15);
            req.body.Password = Passwordhased

            const createDIG = await DIGservices.create(req.body);
            if (createDIG) {
                res.status(201);
                res.send({
                    status: 'DIG created successfully',
                    data: createDIG
                })
            } else {
                res.status(404);
                res.send({
                    status: 'DIG does not created'
                })

            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    },
    login: async (req, res) => {
        try {
            const DIG = await DIGservices.getByEmail(req.body.Email);
            if (DIG !== null) {
                const issimilar = await bcrypt.compare(req.body.Password, DIG.Password);
                if (issimilar) {
                    const DIGtoken = await tokenservices.TokengenerateDIG(DIG);
                    res.status(200);
                    res.send({
                        status: 'DIG Login successfully',
                        data: DIGtoken,
                        
                    })

                } else {
                    res.status(404);
                    res.send({
                        status: 'DIG Login Failed',
                    })

                }
            } else {
                res.status(404);
                res.send({
                    status: 'DIG not found',
                })
            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server Error',
            })

        }
    }


}
module.exports = DIGctrl;