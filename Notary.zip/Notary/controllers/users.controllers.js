//Importing a modules that are requitre for the handling routes

const usersServices = require('../services/users.services');
const PhoneOTPservices = require('../Middleware/PhoneOTP.mdw');
const tokenservices = require('../Middleware/token.mdw');

const twilio = require('twilio');



const usersControllers = {
    userRegistration: async (req, res) => {
        try {
            const userExisted=await usersServices.phonenumber(req.body.phonenumber);
            if(userExisted){
                res.status(409);
                res.send({
                    status:'user Already Register with this Phonenumber'
                })
                return

            }
            const createusers = await usersServices.create(req.body);
            if (createusers) {
                const twilioinfo = await PhoneOTPservices.GeneratePhoneOTP(createusers);
                console.log(twilioinfo);
                await usersServices.update(createusers._id, createusers);
                res.status(201);
                res.send({
                    status: 'OTP send to your Register Phonenumber',
                    data: twilioinfo,

                })
            } else {
                res.status(404);
                res.send({
                    status: 'OTP does not send',

                })

            }
        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server error',

            })

        }

    },
    validateRegisterOTP: async (req, res) => {
        try {
            const users = await usersServices.phonenumber(req.body.phonenumber);
            if (users !== null) {
                issimilar = req.body.otp === users.otp
                if (issimilar) {
                    res.status(200);
                    res.send({
                        status: 'OTP Validated successfully',
                        data: users
                    })
                } else {
                    res.status(404);
                    res.send({
                        status: 'OTP Validation Failed'
                    })
                }
            } else {
                res.status(404);
                res.send({
                    status: 'user not found'
                })

            }

        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server error'
            })
        }
    },
    login: async (req, res) => {
        try {
            const users = await usersServices.phonenumber(req.body.phonenumber);
            if (users !== null) {
                const twilioinfo = await PhoneOTPservices.GeneratePhoneOTP(users);
                await usersServices.update(users._id, users);
                console.log(twilioinfo);
                res.status(200);
                res.send({
                    status: 'OTP send to Your Register MobileNumber',
                    data: twilioinfo
                })
            } else {
                res.status(404);
                res.send({
                    status: 'OTP does not send'
                })
            }

        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    },
    validateloginOTP: async (req, res) => {
        try {
            const users = await usersServices.phonenumber(req.body.phonenumber);
            if (users !== null) {
                issimilar = req.body.otp === users.otp;
                console.log(issimilar);
                if (issimilar) {
                    const token = await tokenservices.Tokengenerate(users);
                    await usersServices.update(users._id, users);

                    res.status(200);
                    res.send({
                        status: 'Validated OTP successfully',
                        token: token
                        

                    })
                } else {
                    res.status(200);
                    res.send({
                        status: 'OTP is invalid'
                    })
                }
            } else {
                res.status(404);
                res.send({
                    status: 'user not found'
                })
            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server Error'
            })

        }
    }


}
module.exports = usersControllers;