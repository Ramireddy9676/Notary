const IGservices = require('../services/IG.services');
const bcrypt = require('bcrypt');
const tokenservices = require('../Middleware/token.mdw');



const IGctrl = {
    createIG: async (req, res) => {
        try {
            const Passwordhased = await bcrypt.hash(req.body.Password, 15);
            req.body.Password = Passwordhased

            const createIG = await IGservices.create(req.body);
            if (createIG) {
                res.status(201);
                res.send({
                    status: 'IG created successfully',
                    data: createIG
                })
            } else {
                res.status(404);
                res.send({
                    status: 'IG does not created'
                })

            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    },
    login: async (req, res) => {
        try {
            const IG = await IGservices.getByEmail(req.body.Email);
            if (IG !== null) {
                const issimilar = await bcrypt.compare(req.body.Password, IG.Password);
                if (issimilar) {
                    const IGtoken = await tokenservices.TokengenerateIG(IG);
                    res.status(200);
                    res.send({
                        status: 'IG Login successfully',
                        data: IGtoken,
                        
                    })

                } else {
                    res.status(404);
                    res.send({
                        status: 'IG Login Failed',
                    })

                }
            } else {
                res.status(404);
                res.send({
                    status: 'IG not found',
                })
            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server Error',
            })

        }
    }


}
module.exports = IGctrl;