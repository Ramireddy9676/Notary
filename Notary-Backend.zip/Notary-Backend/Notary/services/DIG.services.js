const DIGmodels=require('../models/DIG.models');

const DIGservices={
    create:(data)=>{
        const creatreDIG=new DIGmodels(data);
        return creatreDIG.save();
    },
    getByEmail:(Email)=>{
        return DIGmodels.findOne({Email})
    }
}
module.exports=DIGservices;