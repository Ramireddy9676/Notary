const IGmodels=require('../models/IG.models');

const IGservices={
    create:(data)=>{
        const creatreIG=new IGmodels(data);
        return creatreIG.save();
    },
    getByEmail:(Email)=>{
        return IGmodels.findOne({Email})
    }
}
module.exports=IGservices;