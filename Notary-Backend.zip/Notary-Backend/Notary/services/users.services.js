//Importing a modules for handling routes
const usersModels=require('../models/users.models');


const usersServices={
    create:(data)=>{
        const createuser=new usersModels(data);
        return createuser.save();
    },
    // getById:(id)=>{
    //     return usersModels.findById(id);

    // },
    update:(id,data)=>{
        return usersModels.findByIdAndUpdate(id,data,{new:true})
    },
    
    phonenumber:(phonenumber)=>{
        return usersModels.findOne({phonenumber});

    }

}
module.exports=usersServices;
