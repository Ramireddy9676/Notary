const renewalsServices = require('../services/renewals.services');
const ApplicationIDServices = require('../Middleware/ApplicationID.mdw');


const renewalsctrl = {
    createRenewals: async (req, res) => {
        try {

            const RenewalID = await ApplicationIDServices.ApplicationIdgenerate();
            req.body.applicationId = RenewalID;
            req.body.status = 'draft';


            const createrenewals = await renewalsServices.create(req.body);
            if (createrenewals) {
                res.status(201);
                res.send({
                    status: 'Renewal created successfully',
                    data: createrenewals
                })
            } else {
                res.status(404);
                res.send({
                    status: 'Renewal does not created'
                })
            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    },
    getById: async (req, res) => {
        try {

            const renewal = await renewalsServices.getById(req.params.id)
            if (renewal) {
                res.status(200);
                res.send({
                    status: 'Renewals featched successfully',
                    data: renewal
                })
            } else {
                res.status(404);
                res.send({
                    status: 'Renewals featched Featched'
                })

            }



        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server error '
            })

        }
    },
    update: async (req, res) => {
        try {
            const renewal = await renewalsServices.update(req.params.id, req.body);
            if (renewal) {
                res.status(200);
                res.send({
                    status: 'renewal updated successfully',
                    data: renewal
                })
            } else {
                res.status(404);
                res.send({
                    status: 'renewal does not updated'
                })

            }

        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    }


}
module.exports = renewalsctrl;