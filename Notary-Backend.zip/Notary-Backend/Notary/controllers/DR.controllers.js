const DRServices = require('../services/DR.services');
const bcrypt = require('bcrypt');
const tokenservices = require('../Middleware/token.mdw');



const DRctrl = {
    createDR: async (req, res) => {
        try {
            const Passwordhased = await bcrypt.hash(req.body.Password, 15);
            req.body.Password = Passwordhased

            const createDR = await DRServices.create(req.body);
            if (createDR) {
                res.status(201);
                res.send({
                    status: 'DR created successfully',
                    data: createDR
                })
            } else {
                res.status(404);
                res.send({
                    status: 'DR does not created'
                })

            }

        } catch (error) {
            console.log(error)
            res.status(500);
            res.send({
                status: 'Internal server error'
            })

        }
    },
    login: async (req, res) => {
        try {
            const DR = await DRServices.getByEmail(req.body.Email);
            if (DR !== null) {
                const issimilar = await bcrypt.compare(req.body.Password, DR.Password);
                if (issimilar) {
                    const DRtoken = await tokenservices.TokengenerateDR(DR);
                    res.status(200);
                    res.send({
                        status: 'DR Login successfully',
                        data: DRtoken,
                        
                    })

                } else {
                    res.status(404);
                    res.send({
                        status: 'DR Login Failed',
                    })

                }
            } else {
                res.status(404);
                res.send({
                    status: 'DR not found',
                })
            }

        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server Error',
            })

        }
    }


}
module.exports = DRctrl;