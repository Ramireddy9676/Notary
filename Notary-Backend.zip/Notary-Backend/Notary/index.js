//Importing a modules that required for the node js
const express=require('express');
const  mongoose  = require('mongoose');
const bodyparser=require('body-parser');
const cors = require('cors');
const app=express();

app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true,
}));

app.use(bodyparser.json());

//Importing a modules that require for handling routes
const usersRouters=require('./routers/users.routers');
const renewalsRouters=require('./routers/renewals.routers');
const DRRouters=require('./routers/DR.routes');
const DIGRouters=require('./routers/DIG.routers');
const IGRouters=require('./routers/IG.routers');




//Main routers
app.use('/users',usersRouters);
app.use('/renewals',renewalsRouters);
app.use('/DR',DRRouters);
app.use('/DIG',DIGRouters);
app.use('/IG',IGRouters);


















app.listen(5006,function(){
    console.log('server is running on port no:5006')
});

const mongodbconnect=async()=>{
    try{
        await mongoose.connect('mongodb+srv://maramreddy9392:Viswaram999@cluster0.3rxrywx.mongodb.net/Notary?retryWrites=true&w=majority')
        console.log('dp is up')
        

    }catch(error){
        console.log('dp is not working')

    }
}
mongodbconnect();
