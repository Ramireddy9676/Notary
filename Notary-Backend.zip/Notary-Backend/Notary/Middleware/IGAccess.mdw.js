const renewalsServices = require('../services/renewals.services');

const IGAccessServices = {
    getAll: async (req, res, next) => {
        try {
            if (req.IG && req.IG.role === 'IG') {
                const renewals = await renewalsServices.getAll();
                if (renewals && renewals.length > 0) {
                    res.status(200);
                    res.send({
                        status: 'renewals are fetched successfully',
                        data: renewals
                    })
                } else {
                    res.status(404);
                    res.send({
                        status: 'renewals details are not found'
                    })
                }


            } else {
                console.log(error)
                res.status(403);
                res.send({
                    status: 'you donot have access'
                })

            }


        } catch (error) {
            res.status(500);
            res.send({
                status: 'Internal server error'
            })


        }
    },
    getById:async(req,res)=>{
        try{
            if(req.IG&&req.IG.role==='IG'){
                const renewal=await renewalsServices.getById(req.params.id)
                if(renewal){
                    res.status(200);
                    res.send({
                        status:'Renewals featched successfully',
                        data:renewal
                    })
                }else{
                    res.status(404);
                    res.send({
                        status:'Renewals featched Featched'
                    })

                }

            }else{
                res.status(403);
                res.send({
                    status:'you donot have access '
                })
            }

        }catch(error){
            res.status(500);
            res.send({
                status:'Internal server error '
            })

        }
    },
    update:async(req,res)=>{
        try{
            const renewal=await renewalsServices.update(req.params.id,req.body);
            if(renewal){
                renewal.IGcomments=req.body.IGcomments
                const updatedrenewal=await renewal.save();
                res.status(200);
                res.send({
                    status:'renewal updated successfully',
                    data:updatedrenewal
                })
            }else{
                res.status(404);
                res.send({
                    status:'renewal does not updated'
                })

            }

        }catch(error){
            console.log(error)
            res.status(500);
            res.send({
                status:'Internal server error'
            })

        }
    }

}
module.exports = IGAccessServices;