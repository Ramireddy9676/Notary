

const ApplicationIDServices={
     ApplicationIdgenerate:()=>{
        const prefix='NTY'.toString();
        const digits='0123456789';
        let empId = prefix;
        for (let i = 0; i < 13- prefix.length; i++) {
            empId += digits.charAt(Math.floor(Math.random() * digits.length));
        }
        return empId;

     }

}
module.exports=ApplicationIDServices;