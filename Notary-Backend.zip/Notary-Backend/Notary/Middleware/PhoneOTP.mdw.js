const otpservices=require('../Middleware/randomotp.mdw');
const twilio=require('twilio');

const PhoneOTPservices={
    GeneratePhoneOTP:async(data)=>{
        try{
            generatedOTP=await otpservices.GenerateOTP();
            data.otp=generatedOTP
            

            const AccountSID='AC45026aa36bb5efee9bbfdaeb09d55082';
            const AuthToken='6c9651f3c7d158cb6f6ffb81c5db246b';
            const twilioclient=twilio(AccountSID,AuthToken);

            const twilioinfo=await twilioclient.messages.create({
                body:`Notary ONE-TIME-OTP${data.otp}`,
                from:'+19403050532',
                to:'+91'+data.phonenumber
            })
            return twilioinfo

        }catch(error){
            console.log(error);

        }
    }


}
module.exports=PhoneOTPservices;