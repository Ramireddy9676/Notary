const jwt = require('jsonwebtoken');
const usersServices = require('../services/users.services');

const tokenservices = {
    Tokengenerate: async (users) => {
        try {
            const token = await jwt.sign({
                id: users._id,
                Phonenumber: users.Phonenumber,
               role:'user'

            }, 'security key', { expiresIn: '8h' });

            users.token = token;
            await users.save();

            return { message: 'Token generated suvccessfully', token: token }
        } catch (error) {
            return { message: 'Token generated Failed' }


        }
    },
    Authorization: async (req,res,next) => {
        try {
            const tokenInfo = await jwt.verify(req.headers.authorization, 'security key');
            console.log(tokenInfo);
            if (tokenInfo && tokenInfo.role === 'user') {
                req.user = tokenInfo;
                next();
            } else {
                res.status(401);
                res.send({
                    status: 'Your not authorized user or check the Authorization token'
                })

            }

        } catch (error) {
            console.log(error)
            res.status(401);
            res.send({
                status: 'unauthorized user'
            })

         }
    },
    TokengenerateDR: async (DR) => {
        try {
            const token = await jwt.sign({
                id: DR._id,
                Email: DR.Email,
                role:"DR"
               

            }, 'security key', { expiresIn: '8h' });

            DR.token = token;
            await DR.save();

            return { message: 'Token generated suvccessfully', token: token }
        } catch (error) {
            console.log(error)
            return { message: 'Token generated Failed' }


        }
    },
    AuthorizationDR: async (req,res,next) => {
        try {
            const tokenInfo = await jwt.verify(req.headers.authorization, 'security key');
            console.log(tokenInfo);
            if (tokenInfo && tokenInfo.role === 'DR' ) {
                req.DR = tokenInfo;
                next();
            } else {
                res.status(401);
                res.send({
                    status: 'Your not authorized user or check the Authorization token'
                })

            }

        } catch (error) {
            console.log(error)
            res.status(401);
            res.send({
                status: 'unauthorized user'
            })



     }
    },
    TokengenerateDIG:async(DIG)=>{
        try{
            const token=await jwt.sign({
                id:DIG.id,
                Email:DIG.Email,
                role:'DIG'
            },'security key',{expiresIn:'8h'});

            DIG.token=token;
            await DIG.save();

            return{message:'token generated successfully',token:token}

        }catch(error){
            return{message:'token generated Failed'}
        }
    },
    AuthorizationDIG:async(req,res,next)=>{
        try{
            const tokenInfo=await jwt.verify(req.headers.authorization,'security key');
            console.log(tokenInfo);
            if(tokenInfo&&tokenInfo.role==='DIG'){
                req.DIG=tokenInfo;
                next();
            }else{
                res.status(401);
                res.send({
                    status: 'Your not authorized user or check the Authorization token'
                })
            }

        }catch(error){
            console.log(error)
            res.status(401);
            res.send({
                status: 'unauthorized user'
            })
        }
    },
    TokengenerateIG:async(IG)=>{
        try{
            const token=await jwt.sign({
                id:IG.id,
                Email:IG.Email,
                role:'IG'
            },'security key',{expiresIn:'8h'});

            IG.token=token;
            await IG.save();

            return{message:'token generated successfully',token:token}

        }catch(error){
            return{message:'token generated Failed'}
        }
    },
    AuthorizationIG:async(req,res,next)=>{
        try{
            const tokenInfo=await jwt.verify(req.headers.authorization,'security key');
            console.log(tokenInfo);
            if(tokenInfo&&tokenInfo.role==='IG'){
                req.IG=tokenInfo;
                next();
            }else{
                res.status(401);
                res.send({
                    status: 'Your not authorized user or check the Authorization token'
                })
            }

        }catch(error){
            console.log(error)
            res.status(401);
            res.send({
                status: 'unauthorized user'
            })
        }
    }

    
}
module.exports = tokenservices;