const otpservices={
    GenerateOTP:()=>{
        return parseInt(("" + Math.random()).substring(2, 8)); 
    },
}
module.exports=otpservices;

