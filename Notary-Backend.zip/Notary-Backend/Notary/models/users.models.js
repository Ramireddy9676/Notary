const mongoose=require('mongoose');


const usersSchema=mongoose.Schema({
    fullname:{
        type:'String'
    },
    phonenumber:{
        type:'Number'
    },
    email:{
        type:'String'
    },
    otp:{
        type:'Number'
    },
    token:{
        type:'String'
    },
    role:{
        type:'String',
        enum:['user','DR','DIG','IG']
    },
    Lastlogin:{
        type:'Date'
    }
    

})
const usersModels=mongoose.model('users',usersSchema);
module.exports=usersModels;