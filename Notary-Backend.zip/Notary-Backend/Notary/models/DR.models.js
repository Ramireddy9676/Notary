const mongoose=require('mongoose');


const DRSchema=mongoose.Schema({
    Email:{
        type:'String'
    },
    Password:{
        type:'String'
    },
    token:{
        type:'String'
    },
    role: { 
        type: 'String'
    },
    
   

})
const DRmodels=mongoose.model('DR',DRSchema);
module.exports=DRmodels;