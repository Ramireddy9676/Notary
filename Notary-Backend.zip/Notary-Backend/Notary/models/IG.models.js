const mongoose=require('mongoose');


const IGSchema=mongoose.Schema({
    Email:{
        type:'String'
    },
    Password:{
        type:'String'
    },
    token:{
        type:'String'
    },
    role: { 
        type: 'String'
    },
   

})
const IGmodels=mongoose.model('IG',IGSchema);
module.exports=IGmodels;